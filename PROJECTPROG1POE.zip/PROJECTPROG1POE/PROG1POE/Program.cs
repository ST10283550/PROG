﻿using System;

namespace RecipeApp
{
   
    class Ingredient
    {
        // creating the name ,quantity and unit for the recipee
        public string Name { get; set; }
        public double Quantity { get; set; }
        public string Unit { get; set; }
    }

    // Class representing a step in a recipe
    class Step
    {
        public string Description { get; set; }
    }

    class Recipe
    {
        // Creating an array to store the steps and ingredients 
        public Ingredient[] Ingredients { get; set; }
        public Step[] Steps { get; set; }

        
        public void Display()
        {
            Console.WriteLine("Ingredients:");
            foreach (var ingredient in Ingredients)
            {
                Console.WriteLine($"{ingredient.Quantity} {ingredient.Unit} of {ingredient.Name}");
            }

            Console.WriteLine("Steps:");
            for (int i = 0; i < Steps.Length; i++)
            {
                Console.WriteLine($"{i + 1}. {Steps[i].Description}");
            }
        }

        //function to find the scale of the ingredientss
        public void Scale(double factor)
        {
            foreach (var ingredient in Ingredients)
            {
                ingredient.Quantity *= factor;
            }
        }

        public void Reset()
        {
            
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
           
            Recipe kitchenRecipe = new Recipe();   // Create a new recipe object

            Console.Write("How many ingredients will you be using? ");
            int numIngredients = int.Parse(Console.ReadLine());
            kitchenRecipe.Ingredients = new Ingredient[numIngredients];

            for (int i = 0; i < numIngredients; i++)
            // implementing loop for each step
            {
                kitchenRecipe.Ingredients[i] = new Ingredient();
                Console.Write($" Please enter ingredient {i + 1} name: ");
                kitchenRecipe.Ingredients[i].Name = Console.ReadLine();
                Console.Write($"Please enter quantity of {kitchenRecipe.Ingredients[i].Name}: ");
                kitchenRecipe.Ingredients[i].Quantity = double.Parse(Console.ReadLine());
                Console.Write($"Please enter the units for {kitchenRecipe.Ingredients[i].Name}: ");
                kitchenRecipe.Ingredients[i].Unit = Console.ReadLine();
            }

            
            Console.Write("The number of steps: "); // user is asked to input values
            int numSteps = int.Parse(Console.ReadLine());
            kitchenRecipe.Steps = new Step[numSteps];

            
            for (int i = 0; i < numSteps; i++) // implementing loop for each step
            {
                kitchenRecipe.Steps[i] = new Step();
                Console.Write($"Enter step {i + 1} description: ");
                kitchenRecipe.Steps[i].Description = Console.ReadLine();
            }

            kitchenRecipe.Display();  // Final recipe is shown onscreeen

            
            Console.Write("What is the scale for the recipe" +
                "\n is it a half,2 or 3? "); // Prompt user to input a scale factor for the recipe
            double scale = double.Parse(Console.ReadLine());
            kitchenRecipe.Scale(scale);

            
            Console.WriteLine("Here is the final recipe:");
            kitchenRecipe.Display(); // display the modified recipe after scaling


            kitchenRecipe.Reset();  // the recipe is reset

            kitchenRecipe = new Recipe();


            Console.ReadLine(); //program is shut down
        }
    }
}
